Run this JAR file with the master list file "New unsorted ban list.xlsx", and the VLAN list files can be any combination of the other Excel spreadsheets.
